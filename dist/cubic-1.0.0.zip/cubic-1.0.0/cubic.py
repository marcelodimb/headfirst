import math

def cubic_number(num):
    """ Retorna o cubo do numero informado. """
    return math.pow(num, 3)
