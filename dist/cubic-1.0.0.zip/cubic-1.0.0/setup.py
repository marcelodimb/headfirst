from distutils.core import setup

setup(
    name 			= 'cubic',
    version 		= '1.0.0',
    py_modules 		= ['index'],
    author 			= 'marcelodimb',
    author_email	= 'marcelodimb@gmail.com',
    url				= 'http://igeo-server.igeo.ufrj.br/~bueno/',
    description		= 'A simple cubic number printer.'
)